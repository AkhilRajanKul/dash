# scraper/views.py  — COMPLETE FILE (replace your existing one fully)
#
# Key additions vs Phase 10:
#   • /api/scripts/   — the endpoint your dashboard JS calls in initAnalytics()
#   • pipeline_id     — added to the start_pipeline response so the JS can display it
#   • initial_state   — sent over WebSocket on connect so the UI restores on refresh

import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.shortcuts import render
from .models import ScraperScript, ScraperRun, LogLine
from .tasks import launch_full_pipeline


# ─────────────────────────────────────────────────────────────────
# Dashboard HTML
# ─────────────────────────────────────────────────────────────────

def dashboard(request):
    """Serves templates/dashboard.html"""
    return render(request, 'dashboard.html')


# ─────────────────────────────────────────────────────────────────
# /api/scripts/   ← THIS IS WHAT WAS MISSING
# ─────────────────────────────────────────────────────────────────

def scripts_list(request):
    """
    Returns every registered ScraperScript so the dashboard can build
    the stage panels dynamically without hard-coding script names.

    Response shape:
    {
        "scripts": [
            { "id": 1, "name": "Black Hat",  "filename": "blackhat.py",   "stage": "scraper",  "order": 1 },
            { "id": 2, "name": "Inf Insta",  "filename": "infinsta.py",   "stage": "scraper",  "order": 2 },
            ...
            { "id": 8, "name": "Compiler",   "filename": "Compiler.py",   "stage": "compiler", "order": 100 },
            { "id": 9, "name": "Modem",      "filename": "modem.py",      "stage": "modem",    "order": 200 },
        ]
    }
    """
    scripts = ScraperScript.objects.all().order_by('order', 'name')
    out = []
    for s in scripts:
        if s.is_modem:
            stage = 'modem'
        elif s.is_compiler:
            stage = 'compiler'
        else:
            stage = 'scraper'

        out.append({
            'id':       s.id,
            'name':     s.name,
            'filename': s.filename,
            'stage':    stage,
            'order':    s.order,
        })
    return JsonResponse({'scripts': out})


# ─────────────────────────────────────────────────────────────────
# Pipeline control
# ─────────────────────────────────────────────────────────────────

@csrf_exempt
@require_http_methods(['POST'])
def start_pipeline(request):
    """
    Called by the dashboard Start Fetch button.
    Returns pipeline_id (= the compiler run id, used as a human label),
    plus all run IDs so the JS can open per-run log WebSockets.
    """
    try:
        result = launch_full_pipeline()

        # Broadcast pipeline.started over the status WebSocket
        # so ALL connected browsers update simultaneously
        from channels.layers import get_channel_layer
        from asgiref.sync import async_to_sync
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            'pipeline_status',
            {
                'type':              'pipeline.started',
                'pipeline_id':       result.get('compiler_run_id') or result['scraper_run_ids'][0],
                'scraper_run_ids':   result['scraper_run_ids'],
                'compiler_run_id':   result.get('compiler_run_id'),
                'modem_run_id':      result.get('modem_run_id'),
            }
        )

        return JsonResponse({
            'ok':               True,
            'pipeline_id':      result.get('compiler_run_id') or result['scraper_run_ids'][0],
            'scraper_run_ids':  result['scraper_run_ids'],
            'compiler_run_id':  result.get('compiler_run_id'),
            'modem_run_id':     result.get('modem_run_id'),
        })

    except ValueError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)
    except Exception as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=500)


@csrf_exempt
@require_http_methods(['POST'])
def stop_pipeline(request):
    """Revoke all running/pending Celery tasks."""
    from celery import current_app
    running = ScraperRun.objects.filter(status__in=['pending', 'running'])
    count = running.count()
    for run in running:
        if run.task_id:
            current_app.control.revoke(run.task_id, terminate=True, signal='SIGTERM')
        run.status = 'error'
        run.save()
    return JsonResponse({'ok': True, 'stopped': count})


# ─────────────────────────────────────────────────────────────────
# Status / polling fallback
# ─────────────────────────────────────────────────────────────────

def run_status(request, run_id):
    """Single-run status — polling fallback when WS unavailable."""
    try:
        run = ScraperRun.objects.get(pk=run_id)
    except ScraperRun.DoesNotExist:
        return JsonResponse({'error': 'Not found'}, status=404)

    logs = list(
        run.logs.order_by('timestamp')
        .values('level', 'message', 'timestamp')
    )
    for log in logs:
        log['timestamp'] = log['timestamp'].strftime('%H:%M:%S')

    return JsonResponse({
        'run_id':  run.id,
        'status':  run.status,
        'records': run.records,
        'errors':  run.errors,
        'elapsed': run.elapsed_seconds(),
        'logs':    logs,
    })


def all_runs_status(request):
    """Most-recent run for every script — used by dashboard on load."""
    scripts = ScraperScript.objects.all()
    result = []
    for script in scripts:
        latest = script.runs.order_by('-created_at').first()
        result.append({
            'script_id':   script.id,
            'script_name': script.name,
            'run_id':      latest.id if latest else None,
            'status':      latest.status if latest else 'never_run',
            'records':     latest.records if latest else 0,
        })
    return JsonResponse({'runs': result})
