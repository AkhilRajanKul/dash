# vikrant/urls.py  — COMPLETE FILE (replace your existing one)
#
# Added:  path('api/scripts/', ...) — the endpoint the dashboard JS needs

from django.contrib import admin
from django.urls import path
from scraper import views

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),

    # Dashboard HTML page
    path('', views.dashboard, name='dashboard'),

    # ── Scraper API ──────────────────────────────────────────────
    # THIS IS THE ONE THAT WAS MISSING
    path('api/scripts/',          views.scripts_list,    name='scripts_list'),

    # Pipeline control
    path('api/pipeline/start/',   views.start_pipeline,  name='start_pipeline'),
    path('api/pipeline/stop/',    views.stop_pipeline,   name='stop_pipeline'),

    # Status / polling
    path('api/run/<int:run_id>/', views.run_status,      name='run_status'),
    path('api/pipeline/status/',  views.all_runs_status, name='all_runs_status'),
]
