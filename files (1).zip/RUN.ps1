# RUN.ps1  — place this in your project root (same folder as manage.py)
# Run with:  .\RUN.ps1
# Opens 4 windows: Redis, Daphne, Celery worker, Celery beat

# ── 1. Start Redis inside WSL ─────────────────────────────────
Start-Process wsl -ArgumentList "redis-server --daemonize no" -NoNewWindow

Write-Host "Waiting for Redis..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

# ── 2. Start Daphne (ASGI server — replaces runserver) ────────
Start-Process powershell -ArgumentList `
    "-NoExit", "-Command", `
    "daphne -b 0.0.0.0 -p 8000 vikrant.asgi:application" `
    -WindowStyle Normal

Write-Host "Waiting for Daphne..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

# ── 3. Start Celery worker (4 parallel slots) ─────────────────
Start-Process powershell -ArgumentList `
    "-NoExit", "-Command", `
    "celery -A vikrant worker --loglevel=info --concurrency=4 -Q celery" `
    -WindowStyle Normal

Start-Sleep -Seconds 1

# ── 4. (Optional) Celery Beat for scheduled tasks ─────────────
# Uncomment the block below if you want the hourly auto-timer:
#
# Start-Process powershell -ArgumentList `
#     "-NoExit", "-Command", `
#     "celery -A vikrant beat --loglevel=info" `
#     -WindowStyle Normal

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Vikrant pipeline running!" -ForegroundColor Green
Write-Host "  Open: http://localhost:8000/" -ForegroundColor Cyan
Write-Host "  Admin: http://localhost:8000/admin/" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Green
