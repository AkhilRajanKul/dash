# scraper/consumers.py  — COMPLETE FILE (replace your existing one)
#
# Key fix vs Phase 8:
#   • PipelineStatusConsumer.connect() now sends 'initial_state' to the
#     browser on connect — so if you refresh mid-run the UI restores.
#   • pipeline_started handler added so the group_send from views.py works.

import json
from channels.generic.websocket import AsyncWebsocketConsumer


class LogConsumer(AsyncWebsocketConsumer):
    """
    Live terminal logs for one ScraperRun.
    ws://localhost:8000/ws/logs/<run_id>/
    """

    async def connect(self):
        self.run_id    = self.scope['url_route']['kwargs']['run_id']
        self.group     = f'run_logs_{self.run_id}'

        await self.channel_layer.group_add(self.group, self.channel_name)
        await self.accept()

        # Replay history so a page-refresh still shows all past logs
        await self._send_history()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group, self.channel_name)

    async def _send_history(self):
        from scraper.models import LogLine
        from asgiref.sync import sync_to_async

        @sync_to_async
        def get_logs():
            return list(
                LogLine.objects.filter(run_id=self.run_id)
                .values('level', 'message', 'timestamp')
                .order_by('timestamp')
            )

        for log in await get_logs():
            await self.send(text_data=json.dumps({
                'type':    'log',
                'history': True,           # flag so the JS knows these are replayed
                'level':   log['level'],
                'message': log['message'],
                'ts':      log['timestamp'].strftime('%H:%M:%S'),
            }))

    # Called by push_log() in tasks.py via channel_layer.group_send(type='log.message')
    async def log_message(self, event):
        await self.send(text_data=json.dumps({
            'type':    'log',
            'history': False,
            'level':   event['level'],
            'message': event['message'],
            'ts':      event.get('ts', ''),
        }))


class PipelineStatusConsumer(AsyncWebsocketConsumer):
    """
    Global broadcast channel — progress bars + pipeline events.
    ws://localhost:8000/ws/pipeline/status/
    """

    async def connect(self):
        await self.channel_layer.group_add('pipeline_status', self.channel_name)
        await self.accept()

        # Send current state of all runs so a fresh browser tab sees the right UI
        await self._send_initial_state()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard('pipeline_status', self.channel_name)

    async def _send_initial_state(self):
        from scraper.models import ScraperScript
        from asgiref.sync import sync_to_async

        @sync_to_async
        def get_state():
            state = []
            for script in ScraperScript.objects.all():
                latest = script.runs.order_by('-created_at').first()
                if latest:
                    state.append({
                        'script_id': script.id,
                        'run_id':    latest.id,
                        'status':    latest.status,
                        'records':   latest.records,
                    })
            return state

        state = await get_state()
        await self.send(text_data=json.dumps({
            'type':  'initial_state',
            'state': state,
        }))

    # ── Handlers — name maps to 'type' field in group_send (dot → underscore) ──

    async def status_update(self, event):
        """Fired by update_run_status() in tasks.py"""
        await self.send(text_data=json.dumps({
            'type':    'status',
            'run_id':  event['run_id'],
            'status':  event['status'],
            'records': event.get('records', 0),
            'errors':  event.get('errors', 0),
        }))

    async def pipeline_started(self, event):
        """Fired by start_pipeline() in views.py so all tabs know a run started."""
        await self.send(text_data=json.dumps({
            'type':             'pipeline.started',
            'pipeline_id':      event['pipeline_id'],
            'scraper_run_ids':  event['scraper_run_ids'],
            'compiler_run_id':  event.get('compiler_run_id'),
            'modem_run_id':     event.get('modem_run_id'),
        }))
