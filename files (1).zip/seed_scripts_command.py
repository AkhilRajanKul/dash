# scraper/management/commands/seed_scripts.py
#
# Run once after migrate:
#   python manage.py seed_scripts
#
# This creates the ScraperScript rows so the dashboard can load them.
# Edit the SCRIPTS list below to match your actual .py filenames in scripts/.

from django.core.management.base import BaseCommand
from scraper.models import ScraperScript


# ──────────────────────────────────────────────────────────────────
# EDIT THIS LIST to match your actual files in the scripts/ folder.
# Rules:
#   is_compiler=False, is_modem=False  → regular scraper (runs in parallel)
#   is_compiler=True                   → runs after ALL scrapers finish
#   is_modem=True                      → runs after compiler finishes
# ──────────────────────────────────────────────────────────────────
SCRIPTS = [
    # (name,              filename,              is_compiler, is_modem, order)
    ('Black Hat',         'blackhat_scraper.py',  False, False, 1),
    ('Inf Insta',         'infinsta_scraper.py',  False, False, 2),
    ('Inshar',            'inshar_scraper.py',    False, False, 3),
    ('MR Meta',           'mrmeta_scraper.py',    False, False, 4),
    ('WX BD',             'wxbd_scraper.py',      False, False, 5),
    ('WX SAR',            'wxsar_scraper.py',     False, False, 6),
    ('XNA Meta',          'xnameta_scraper.py',   False, False, 7),
    ('Compiler',          'Compiler.py',           True,  False, 100),
    ('Modem Reboot',      'modem_reboot.py',       False, True,  200),
]


class Command(BaseCommand):
    help = 'Seeds the ScraperScript table with your scraper + compiler + modem scripts'

    def handle(self, *args, **options):
        created = 0
        updated = 0
        for name, filename, is_compiler, is_modem, order in SCRIPTS:
            obj, was_created = ScraperScript.objects.update_or_create(
                name=name,
                defaults={
                    'filename':    filename,
                    'is_compiler': is_compiler,
                    'is_modem':    is_modem,
                    'order':       order,
                }
            )
            if was_created:
                created += 1
                self.stdout.write(self.style.SUCCESS(f'  Created: {name}'))
            else:
                updated += 1
                self.stdout.write(f'  Updated: {name}')

        self.stdout.write(self.style.SUCCESS(
            f'\nDone — {created} created, {updated} updated.'
        ))
        self.stdout.write(
            'Go to http://localhost:8000/admin/scraper/scraperscript/ '
            'to verify or edit script entries.'
        )
