# vikrant/asgi.py  — COMPLETE FILE (replace your existing one)
#
# This wires Django Channels so Daphne serves both:
#   • HTTP requests   → standard Django views
#   • WebSocket /ws/  → your consumers

import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import scraper.routing   # your websocket URL patterns

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'vikrant.settings')

application = ProtocolTypeRouter({
    # Normal HTTP — handled by Django as usual
    'http': get_asgi_application(),

    # WebSocket — wrapped in auth middleware so request.user is available
    'websocket': AuthMiddlewareStack(
        URLRouter(
            scraper.routing.websocket_urlpatterns
        )
    ),
})
