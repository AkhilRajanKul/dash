"""
HTTP API views for the Vikrant Dashboard.
Every endpoint returns JSON except dashboard() which renders HTML.
"""

import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.shortcuts import render
from django.utils import timezone

from .models import ScraperScript, ScraperRun, LogLine, PipelineRun

logger = logging.getLogger('scraper')


# ── Page ─────────────────────────────────────────────────────────
def dashboard(request):
    return render(request, 'dashboard.html')


# ── Pipeline control ──────────────────────────────────────────────
@csrf_exempt
@require_http_methods(['POST'])
def start_pipeline(request):
    """
    POST /api/pipeline/start/
    Called when user clicks "Start Fetch".
    Creates ScraperRun rows then fires the Celery chord.
    """
    from .tasks import launch_full_pipeline
    try:
        result = launch_full_pipeline(triggered_by='manual')
        return JsonResponse(result)
    except ValueError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)
    except Exception as e:
        logger.error(f'start_pipeline: {e}', exc_info=True)
        return JsonResponse({'ok': False, 'error': str(e)}, status=500)


@csrf_exempt
@require_http_methods(['POST'])
def stop_pipeline(request):
    """
    POST /api/pipeline/stop/
    Revokes all active Celery tasks and marks runs as error.
    """
    from celery import current_app

    runs = ScraperRun.objects.filter(status__in=['pending', 'running'])
    stopped = 0
    for run in runs:
        if run.task_id:
            try:
                current_app.control.revoke(run.task_id, terminate=True, signal='SIGTERM')
            except Exception:
                pass
        run.status   = 'error'
        run.ended_at = timezone.now()
        run.save()
        stopped += 1

    PipelineRun.objects.filter(status='running').update(
        status='stopped', ended_at=timezone.now()
    )
    return JsonResponse({'ok': True, 'stopped': stopped})


# ── Status endpoints ───────────────────────────────────────────────
def all_runs_status(request):
    """
    GET /api/pipeline/status/
    Returns latest run for every registered script.
    Called on page load to initialise progress panels.
    """
    result = []
    for script in ScraperScript.objects.filter(is_active=True):
        latest = script.runs.order_by('-created_at').first()
        result.append({
            'script_id':   script.id,
            'script_name': script.name,
            'filename':    script.filename,
            'stage':       script.stage_label(),
            'run_id':      latest.id              if latest else None,
            'status':      latest.status          if latest else 'never_run',
            'records':     latest.records         if latest else 0,
            'errors':      latest.errors          if latest else 0,
            'elapsed':     latest.elapsed_seconds() if latest else 0,
            'task_id':     latest.task_id         if latest else '',
        })
    return JsonResponse({'ok': True, 'scripts': result})


def run_status(request, run_id):
    """GET /api/run/<run_id>/  — polling fallback."""
    try:
        run = ScraperRun.objects.select_related('script').get(pk=run_id)
    except ScraperRun.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    return JsonResponse({'ok': True, 'run': run.to_dict()})


def run_logs(request, run_id):
    """GET /api/run/<run_id>/logs/  — full log history for a run."""
    try:
        run = ScraperRun.objects.get(pk=run_id)
    except ScraperRun.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    logs = [l.to_dict() for l in run.logs.all()]
    return JsonResponse({'ok': True, 'run_id': run_id, 'logs': logs})


def list_scripts(request):
    """GET /api/scripts/  — all registered ScraperScript rows."""
    scripts = [
        {
            'id':        s.id,
            'name':      s.name,
            'filename':  s.filename,
            'stage':     s.stage_label(),
            'is_active': s.is_active,
            'order':     s.order,
        }
        for s in ScraperScript.objects.all()
    ]
    return JsonResponse({'ok': True, 'scripts': scripts})
