================================================================
  VIKRANT DASHBOARD — COMPLETE SETUP GUIDE
  Read this entirely before running anything
================================================================

WHAT THIS PROJECT DOES
-----------------------
Runs 7 scraper scripts (winfix.fun affiliate panels) + 1 Compiler
+ 1 modem reboot — all managed through a web dashboard with live
terminal logs, progress bars, and a PostgreSQL database.

YOUR SCRIPTS MAPPED:
  Scrapers (run in parallel):
    1. Black_Hat_-_Meta_creeper.py   (user: winfix_bh)
    2. Inf_-_Insta_creeper.py        (user: adweb)
    3. Inshar_-_Meta_creeper.py      (user: wx_inhsar)
    4. MR_-_Meta_creeper.py          (user: wx_mr)
    5. WX_BD_Creeper.py              (user: wx_bd)
    6. WX_SAR_creeper.py             (user: wx_sar)
    7. XNA_-_Meta_creeper.py         (user: wx_xm)

  After all scrapers finish:
    8. Compiler.py                   (dedup + Zoho push)

  After compiler:
    9. modem_reboot.py               (modem reboot via Selenium)


PREREQUISITES (install these first)
-------------------------------------
1. Python 3.11+       https://python.org/downloads
   - During install: CHECK "Add Python to PATH"

2. PostgreSQL 16      https://www.postgresql.org/download/windows/
   - Remember the password you set for 'postgres' user
   - Default port: 5432

3. Redis for Windows  https://github.com/microsoftarchive/redis/releases
   - Download: Redis-x64-3.0.504.msi
   - Install with defaults (runs as Windows service)

4. Google Chrome      (latest version)
   - Required for Selenium scrapers


STEP-BY-STEP SETUP IN POWERSHELL
----------------------------------

Open PowerShell as Administrator (right-click -> Run as Administrator)

STEP 1: Navigate to your project folder
  cd C:\Users\Akhil\Desktop\VikrantDashboard

STEP 2: Create virtual environment
  python -m venv venv
  .\venv\Scripts\Activate.ps1

  (If you get "execution policy" error, first run:)
  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

STEP 3: Install all Python packages
  pip install django==4.2 celery==5.3.6 redis==5.0.3 channels==4.0.0 channels-redis==4.2.0 daphne==4.0.0 djangorestframework==3.14.0 psycopg2-binary==2.9.9 pandas requests selenium webdriver-manager undetected-chromedriver selenium-stealth fake-useragent colorama Pillow

STEP 4: Create the PostgreSQL database
  (In a NEW PowerShell window)
  psql -U postgres
  
  Then in the psql shell, paste these commands:
    CREATE DATABASE vikrant_db;
    CREATE USER vikrant_user WITH PASSWORD 'vikrant2024secure';
    GRANT ALL PRIVILEGES ON DATABASE vikrant_db TO vikrant_user;
    \c vikrant_db
    GRANT ALL ON SCHEMA public TO vikrant_user;
    \q

STEP 5: Update your data folder paths in settings.py
  Open vikrant\settings.py and change:
    DATA_INPUT_PATH = r"C:\Users\Akhil\Desktop\Vikrant\data\input"
    DATA_REPO_PATH  = r"C:\Users\Akhil\Desktop\Vikrant\data\repo"

STEP 6: Run migrations
  (Back in your main PowerShell with venv active)
  python manage.py makemigrations scraper
  python manage.py migrate

STEP 7: Create admin user
  python manage.py createsuperuser
  (Enter: username=admin, email=anything, password=admin123)

STEP 8: Seed the script registry
  python manage.py seed_scripts

STEP 9: Verify Redis is running
  redis-cli ping
  (Should respond: PONG)

STEP 10: Start everything
  .\RUN.ps1
  
  This opens 3 windows:
  - Django/Daphne server (port 8000)
  - Celery worker (runs your scripts)
  - Celery beat (hourly scheduler)

STEP 11: Open the dashboard
  http://localhost:8000
  Admin: http://localhost:8000/admin  (admin / admin123)


WHERE TO PUT YOUR SCRIPT FILES
--------------------------------
Copy all 9 of your .py files into the 'scripts' folder:
  VikrantDashboard\scripts\Black_Hat_-_Meta_creeper.py
  VikrantDashboard\scripts\Inf_-_Insta_creeper.py
  VikrantDashboard\scripts\Inshar_-_Meta_creeper.py
  VikrantDashboard\scripts\MR_-_Meta_creeper.py
  VikrantDashboard\scripts\WX_BD_Creeper.py
  VikrantDashboard\scripts\WX_SAR_creeper.py
  VikrantDashboard\scripts\XNA_-_Meta_creeper.py
  VikrantDashboard\scripts\Compiler.py
  VikrantDashboard\scripts\modem_reboot.py


IMPORTANT: UPDATE PATHS IN YOUR SCRIPTS
-----------------------------------------
Your scripts have hardcoded paths like:
  OUTPUT_PATH = r'C:\Users\Akhil\Desktop\Vikrant\data\input'

The project will update these automatically when running via Django.
But if you run them standalone, update to your actual path.


TROUBLESHOOTING
----------------
"ModuleNotFoundError":      .\venv\Scripts\Activate.ps1  (activate venv first)
"Redis connection refused":  Check Redis service is running in Windows Services
"PostgreSQL error":          Check your password matches in settings.py
"Chrome driver error":       Update Chrome to latest version
"Port 8000 in use":          netstat -ano | findstr :8000  then kill the PID


================================================================
