# ================================================================
# VIKRANT DASHBOARD - ONE-TIME SETUP SCRIPT
# Run ONCE after downloading the project
# Usage: Right-click -> Run with PowerShell (as Administrator)
# ================================================================

param(
    [string]$DbPassword = "vikrant2024secure",
    [string]$DbName     = "vikrant_db",
    [string]$DbUser     = "vikrant_user"
)

$Host.UI.RawUI.WindowTitle = "Vikrant Dashboard - Setup"
$ProjectRoot = $PSScriptRoot
$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "  ╔════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║   VIKRANT DASHBOARD - SETUP v2.0  ║" -ForegroundColor Cyan
Write-Host "  ╚════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ── Fix execution policy ──────────────────────────────────
Write-Host "  Fixing PowerShell execution policy..." -ForegroundColor Yellow
try {
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
    Write-Host "  OK" -ForegroundColor Green
} catch { Write-Host "  (skipped)" -ForegroundColor Gray }

# ── Check Python ──────────────────────────────────────────
Write-Host ""
Write-Host "  [1/8] Checking Python..." -ForegroundColor Yellow
$pyVersion = python --version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "  ERROR: Python not found!" -ForegroundColor Red
    Write-Host "  Install from https://python.org (check 'Add to PATH')" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "  Found: $pyVersion" -ForegroundColor Green

# ── Create virtual environment ────────────────────────────
Write-Host ""
Write-Host "  [2/8] Creating virtual environment..." -ForegroundColor Yellow
if (-Not (Test-Path "$ProjectRoot\venv")) {
    python -m venv "$ProjectRoot\venv"
    Write-Host "  Created" -ForegroundColor Green
} else {
    Write-Host "  Already exists" -ForegroundColor Gray
}
& "$ProjectRoot\venv\Scripts\Activate.ps1"

# ── Install packages ──────────────────────────────────────
Write-Host ""
Write-Host "  [3/8] Installing packages (3-5 minutes)..." -ForegroundColor Yellow
pip install --upgrade pip -q
pip install `
    django==4.2 `
    celery==5.3.6 `
    redis==5.0.3 `
    channels==4.0.0 `
    "channels-redis==4.2.0" `
    daphne==4.0.0 `
    djangorestframework==3.14.0 `
    psycopg2-binary==2.9.9 `
    django-celery-beat==2.5.0 `
    django-celery-results==2.5.1 `
    pandas `
    requests `
    selenium `
    webdriver-manager `
    undetected-chromedriver `
    selenium-stealth `
    fake-useragent `
    colorama `
    Pillow `
    2>&1 | Tee-Object "$ProjectRoot\pip_log.txt"

Write-Host "  Packages installed" -ForegroundColor Green

# ── Create folder structure ───────────────────────────────
Write-Host ""
Write-Host "  [4/8] Creating folders..." -ForegroundColor Yellow
$folders = @(
    "scripts", "templates", "static\css", "static\js",
    "data\input", "data\repo",
    "vikrant", "scraper\migrations"
)
foreach ($f in $folders) {
    $p = Join-Path $ProjectRoot $f
    if (-Not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null }
}
Write-Host "  Done" -ForegroundColor Green

# ── Setup PostgreSQL database ─────────────────────────────
Write-Host ""
Write-Host "  [5/8] Setting up PostgreSQL database..." -ForegroundColor Yellow
Write-Host "  (Requires PostgreSQL to be installed and running)" -ForegroundColor Gray

$psqlPath = "C:\Program Files\PostgreSQL\16\bin\psql.exe"
if (-Not (Test-Path $psqlPath)) {
    $psqlPath = "C:\Program Files\PostgreSQL\15\bin\psql.exe"
}
if (-Not (Test-Path $psqlPath)) {
    $psqlPath = (Get-Command psql -ErrorAction SilentlyContinue)?.Source
}

if ($psqlPath -and (Test-Path $psqlPath)) {
    $sqlCommands = @"
DO `$`$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '$DbUser') THEN
    CREATE USER $DbUser WITH PASSWORD '$DbPassword';
  END IF;
END `$`$;
CREATE DATABASE $DbName OWNER $DbUser;
GRANT ALL PRIVILEGES ON DATABASE $DbName TO $DbUser;
"@
    $sqlCommands | & $psqlPath -U postgres 2>&1 | Out-Null
    
    # Grant schema permissions
    $schemaGrant = "GRANT ALL ON SCHEMA public TO $DbUser;"
    $schemaGrant | & $psqlPath -U postgres -d $DbName 2>&1 | Out-Null
    
    Write-Host "  Database '$DbName' ready" -ForegroundColor Green
} else {
    Write-Host "  PostgreSQL not found — using SQLite fallback" -ForegroundColor Yellow
    Write-Host "  Install PostgreSQL for production use" -ForegroundColor Gray
    # Patch settings to use SQLite
    $settingsPath = Join-Path $ProjectRoot "vikrant\settings.py"
    if (Test-Path $settingsPath) {
        (Get-Content $settingsPath) -replace "USE_POSTGRES = True", "USE_POSTGRES = False" |
            Set-Content $settingsPath
    }
}

# ── Run Django migrations ─────────────────────────────────
Write-Host ""
Write-Host "  [6/8] Running database migrations..." -ForegroundColor Yellow
Set-Location $ProjectRoot
python manage.py makemigrations scraper 2>&1
python manage.py migrate 2>&1
Write-Host "  Done" -ForegroundColor Green

# ── Create superuser ──────────────────────────────────────
Write-Host ""
Write-Host "  [7/8] Creating admin user..." -ForegroundColor Yellow
$createUser = @"
import django, os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','vikrant.settings')
django.setup()
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin','admin@vikrant.local','admin123')
    print('Created admin user')
else:
    print('Admin user already exists')
"@
$createUser | python manage.py shell
Write-Host "  admin / admin123" -ForegroundColor Green

# ── Seed script registry ──────────────────────────────────
Write-Host ""
Write-Host "  [8/8] Seeding scraper script registry..." -ForegroundColor Yellow
python manage.py seed_scripts
Write-Host "  Done" -ForegroundColor Green

# ── Final summary ─────────────────────────────────────────
Write-Host ""
Write-Host "  ╔════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║           SETUP COMPLETE!              ║" -ForegroundColor Green
Write-Host "  ╠════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "  ║                                        ║" -ForegroundColor Green
Write-Host "  ║  1. Copy your .py scripts to:          ║" -ForegroundColor White
Write-Host "  ║     $ProjectRoot\scripts\   ║" -ForegroundColor Gray
Write-Host "  ║                                        ║" -ForegroundColor Green
Write-Host "  ║  2. Start everything:  .\RUN.ps1       ║" -ForegroundColor White
Write-Host "  ║                                        ║" -ForegroundColor Green
Write-Host "  ║  3. Open: http://localhost:8000        ║" -ForegroundColor White
Write-Host "  ║                                        ║" -ForegroundColor Green
Write-Host "  ╚════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to close"
