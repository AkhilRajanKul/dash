import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'vikrant.settings')

app = Celery('vikrant')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()
