import json
import logging
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async

logger = logging.getLogger('scraper')


class LogConsumer(AsyncWebsocketConsumer):
    """
    ws://localhost:8000/ws/logs/<run_id>/
    Streams log lines for a specific ScraperRun to the browser terminal.
    """

    async def connect(self):
        self.run_id     = int(self.scope['url_route']['kwargs']['run_id'])
        self.group_name = f'run_logs_{self.run_id}'
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()
        # Send all historical logs immediately so page refresh works
        await self._replay_history()

    async def disconnect(self, code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def _replay_history(self):
        @sync_to_async
        def _get():
            from scraper.models import LogLine
            return list(
                LogLine.objects.filter(run_id=self.run_id)
                .order_by('timestamp')
                .values('level', 'message', 'timestamp')
            )
        try:
            for log in await _get():
                await self.send(text_data=json.dumps({
                    'type':    'log',
                    'run_id':  self.run_id,
                    'level':   log['level'],
                    'message': log['message'],
                    'ts':      log['timestamp'].strftime('%H:%M:%S'),
                    'history': True,
                }))
        except Exception as e:
            logger.warning(f'History replay failed: {e}')

    # Called by group_send with type='log.message'
    async def log_message(self, event):
        await self.send(text_data=json.dumps({
            'type':    'log',
            'run_id':  event.get('run_id', self.run_id),
            'level':   event['level'],
            'message': event['message'],
            'ts':      event.get('ts', ''),
            'history': False,
        }))


class PipelineStatusConsumer(AsyncWebsocketConsumer):
    """
    ws://localhost:8000/ws/pipeline/status/
    Broadcasts pipeline-level events: status changes, starts, completions.
    All browser tabs subscribe to this one global channel.
    """

    async def connect(self):
        await self.channel_layer.group_add('pipeline_status', self.channel_name)
        await self.accept()
        await self._send_initial_state()

    async def disconnect(self, code):
        await self.channel_layer.group_discard('pipeline_status', self.channel_name)

    async def _send_initial_state(self):
        """Send current status of all scripts so UI initialises correctly."""
        @sync_to_async
        def _get():
            from scraper.models import ScraperScript
            result = []
            for s in ScraperScript.objects.filter(is_active=True):
                latest = s.runs.order_by('-created_at').first()
                result.append({
                    'script_id':   s.id,
                    'script_name': s.name,
                    'filename':    s.filename,
                    'stage':       s.stage_label(),
                    'run_id':      latest.id      if latest else None,
                    'status':      latest.status  if latest else 'never_run',
                    'records':     latest.records if latest else 0,
                    'errors':      latest.errors  if latest else 0,
                    'elapsed':     latest.elapsed_seconds() if latest else 0,
                })
            return result
        try:
            state = await _get()
            await self.send(text_data=json.dumps({
                'type':  'initial_state',
                'state': state,
            }))
        except Exception as e:
            logger.warning(f'Initial state send failed: {e}')

    # type='status.update'
    async def status_update(self, event):
        await self.send(text_data=json.dumps({
            'type':    'status',
            'run_id':  event['run_id'],
            'status':  event['status'],
            'records': event.get('records', 0),
            'errors':  event.get('errors',  0),
        }))

    # type='global.log'
    async def global_log(self, event):
        await self.send(text_data=json.dumps({
            'type':    'global_log',
            'level':   event['level'],
            'message': event['message'],
            'ts':      event.get('ts', ''),
        }))

    # type='pipeline.started'
    async def pipeline_started(self, event):
        await self.send(text_data=json.dumps(event))
