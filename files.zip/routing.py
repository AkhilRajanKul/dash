from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    re_path(r'^ws/logs/(?P<run_id>\d+)/$',  consumers.LogConsumer.as_asgi()),
    re_path(r'^ws/pipeline/status/$',        consumers.PipelineStatusConsumer.as_asgi()),
]
