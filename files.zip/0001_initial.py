from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True
    dependencies = []

    operations = [
        migrations.CreateModel(
            name='ScraperScript',
            fields=[
                ('id',          models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('name',        models.CharField(max_length=120, unique=True)),
                ('filename',    models.CharField(max_length=200)),
                ('description', models.TextField(blank=True)),
                ('is_compiler', models.BooleanField(default=False)),
                ('is_modem',    models.BooleanField(default=False)),
                ('is_active',   models.BooleanField(default=True)),
                ('order',       models.IntegerField(default=0)),
                ('created_at',  models.DateTimeField(auto_now_add=True)),
            ],
            options={'ordering': ['order', 'name']},
        ),
        migrations.CreateModel(
            name='PipelineRun',
            fields=[
                ('id',           models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('status',       models.CharField(
                    choices=[('pending','Pending'),('running','Running'),
                             ('done','Done'),('error','Error'),('stopped','Stopped')],
                    default='pending', max_length=20)),
                ('triggered_by', models.CharField(default='manual', max_length=50)),
                ('started_at',   models.DateTimeField(blank=True, null=True)),
                ('ended_at',     models.DateTimeField(blank=True, null=True)),
                ('created_at',   models.DateTimeField(auto_now_add=True)),
            ],
            options={'ordering': ['-created_at']},
        ),
        migrations.CreateModel(
            name='ScraperRun',
            fields=[
                ('id',         models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('pipeline',   models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='scraper_runs',
                    to='scraper.pipelinerun')),
                ('script',     models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='runs',
                    to='scraper.scraperscript')),
                ('status',     models.CharField(
                    choices=[('pending','Pending'),('running','Running'),
                             ('done','Done'),('error','Error'),('skipped','Skipped')],
                    default='pending', max_length=20)),
                ('task_id',    models.CharField(blank=True, max_length=155, db_index=True)),
                ('records',    models.IntegerField(default=0)),
                ('errors',     models.IntegerField(default=0)),
                ('started_at', models.DateTimeField(blank=True, null=True)),
                ('ended_at',   models.DateTimeField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
            ],
            options={'ordering': ['-created_at']},
        ),
        migrations.CreateModel(
            name='LogLine',
            fields=[
                ('id',        models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('run',       models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='logs',
                    to='scraper.scraperrun')),
                ('level',     models.CharField(
                    choices=[('INFO','Info'),('OK','OK'),('WARN','Warning'),
                             ('ERR','Error'),('CMD','Cmd'),('SYS','System'),('DATA','Data')],
                    default='INFO', max_length=10)),
                ('message',   models.TextField()),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
            ],
            options={'ordering': ['timestamp']},
        ),
        migrations.AddIndex(
            model_name='scraperrun',
            index=models.Index(fields=['status', 'created_at'],
                               name='scraper_run_status_idx'),
        ),
        migrations.AddIndex(
            model_name='logline',
            index=models.Index(fields=['run', 'timestamp'],
                               name='scraper_log_run_ts_idx'),
        ),
    ]
