# ================================================================
# VIKRANT DASHBOARD - START ALL SERVICES
# Double-click or run: .\RUN.ps1
# ================================================================

$Host.UI.RawUI.WindowTitle = "Vikrant Dashboard - Launcher"
$ProjectRoot = $PSScriptRoot

Write-Host ""
Write-Host "  ╔══════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║   VIKRANT DASHBOARD LAUNCHER v2.0   ║" -ForegroundColor Cyan
Write-Host "  ╚══════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Activate venv
$activate = "$ProjectRoot\venv\Scripts\Activate.ps1"
if (Test-Path $activate) {
    & $activate
} else {
    Write-Host "  ERROR: venv not found. Run SETUP.ps1 first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# ── Check Redis ───────────────────────────────────────────
Write-Host "  [1/3] Checking Redis..." -ForegroundColor Yellow
try {
    $ping = & redis-cli ping 2>&1
    if ($ping -match "PONG") {
        Write-Host "        Redis OK" -ForegroundColor Green
    } else {
        Write-Host "        Starting Redis service..." -ForegroundColor Yellow
        Start-Service -Name "Redis" -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
} catch {
    Write-Host "        Redis not found! Install from README.txt" -ForegroundColor Red
}

# ── Start Django/Daphne ───────────────────────────────────
Write-Host "  [2/3] Starting Django server..." -ForegroundColor Yellow
$djangoArgs = @(
    "-NoExit", "-Command",
    "cd '$ProjectRoot'; " +
    ".\venv\Scripts\Activate.ps1; " +
    "`$Host.UI.RawUI.WindowTitle = 'Vikrant - Django Server'; " +
    "Write-Host '  DJANGO / DAPHNE SERVER  ' -BackgroundColor DarkGreen -ForegroundColor White; " +
    "Write-Host '  http://localhost:8000  ' -ForegroundColor Green; " +
    "Write-Host ''; " +
    "daphne -b 0.0.0.0 -p 8000 vikrant.asgi:application"
)
Start-Process powershell -ArgumentList $djangoArgs
Start-Sleep -Seconds 3

# ── Start Celery Worker ───────────────────────────────────
Write-Host "  [3/3] Starting Celery worker..." -ForegroundColor Yellow
$celeryArgs = @(
    "-NoExit", "-Command",
    "cd '$ProjectRoot'; " +
    ".\venv\Scripts\Activate.ps1; " +
    "`$Host.UI.RawUI.WindowTitle = 'Vikrant - Celery Worker'; " +
    "Write-Host '  CELERY WORKER (concurrency=4)  ' -BackgroundColor DarkMagenta -ForegroundColor White; " +
    "Write-Host '  Waiting for tasks from Redis...  ' -ForegroundColor Magenta; " +
    "Write-Host ''; " +
    "celery -A vikrant worker --loglevel=info --concurrency=4 --pool=solo -E"
)
Start-Process powershell -ArgumentList $celeryArgs
Start-Sleep -Seconds 3

# ── Start Celery Beat (scheduler) ─────────────────────────
$beatArgs = @(
    "-NoExit", "-Command",
    "cd '$ProjectRoot'; " +
    ".\venv\Scripts\Activate.ps1; " +
    "`$Host.UI.RawUI.WindowTitle = 'Vikrant - Celery Beat'; " +
    "Write-Host '  CELERY BEAT (hourly scheduler)  ' -BackgroundColor DarkBlue -ForegroundColor White; " +
    "Write-Host ''; " +
    "celery -A vikrant beat --loglevel=info --scheduler django_celery_beat.schedulers:DatabaseScheduler"
)
Start-Process powershell -ArgumentList $beatArgs

Start-Sleep -Seconds 4

Write-Host ""
Write-Host "  ╔══════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║         ALL SERVICES STARTED         ║" -ForegroundColor Green
Write-Host "  ╠══════════════════════════════════════╣" -ForegroundColor Green
Write-Host "  ║  Dashboard : http://localhost:8000   ║" -ForegroundColor White
Write-Host "  ║  Admin     : http://localhost:8000/admin  ║" -ForegroundColor White
Write-Host "  ║  User: admin  Password: admin123     ║" -ForegroundColor Gray
Write-Host "  ╚══════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

Start-Sleep -Seconds 2
Start-Process "http://localhost:8000"
