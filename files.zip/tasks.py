"""
Celery tasks — the engine of the Vikrant pipeline.

HOW IT WORKS:
  1. Browser calls POST /api/pipeline/start/
  2. Django view calls launch_full_pipeline()
  3. Celery group() dispatches all 7 scrapers to Redis simultaneously
  4. Each scraper task is picked up by a separate worker slot and runs
  5. As each script calls print(), LogCapture intercepts and streams
     the line over WebSocket to the browser terminal in real time
  6. When ALL 7 scrapers finish, Celery automatically starts the compiler
  7. When compiler finishes, modem reboot starts
  8. All status changes push to WebSocket so progress bars update live
"""

import os
import sys
import io
import re
import time
import logging
import importlib.util
import traceback
from datetime import datetime

from celery import shared_task, group, chain
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.utils import timezone
from django.conf import settings

logger = logging.getLogger('scraper')


# ──────────────────────────────────────────────────────────────
# WEBSOCKET BROADCAST
# ──────────────────────────────────────────────────────────────

def _ws_send(group_name: str, payload: dict):
    """Send a message to all browsers subscribed to this WebSocket group."""
    try:
        layer = get_channel_layer()
        async_to_sync(layer.group_send)(group_name, payload)
    except Exception as exc:
        logger.warning(f'WS broadcast failed [{group_name}]: {exc}')


def push_log(run_id: int, level: str, message: str):
    """
    Save log line to PostgreSQL AND push to browser terminal via WebSocket.
    Called hundreds of times per script — one line at a time.
    """
    from scraper.models import LogLine, ScraperRun
    try:
        run = ScraperRun.objects.get(pk=run_id)
        LogLine.objects.create(run=run, level=level, message=message)
    except Exception as exc:
        logger.warning(f'LogLine save failed: {exc}')
        return

    _ws_send(
        f'run_logs_{run_id}',
        {
            'type':    'log.message',
            'run_id':  run_id,
            'level':   level,
            'message': message,
            'ts':      datetime.now().strftime('%H:%M:%S'),
        }
    )


def push_status(run_id: int, status: str, records: int = 0, errors: int = 0):
    """Push a run status change to all browsers (drives progress bars)."""
    _ws_send(
        'pipeline_status',
        {
            'type':    'status.update',
            'run_id':  run_id,
            'status':  status,
            'records': records,
            'errors':  errors,
        }
    )


def update_run(run_id: int, status: str = None, records: int = None,
               errors: int = None, task_id: str = None):
    """Update ScraperRun in DB and broadcast the change."""
    from scraper.models import ScraperRun
    try:
        run = ScraperRun.objects.get(pk=run_id)
        if task_id:
            run.task_id = task_id
        if status:
            run.status = status
            if status == 'running' and not run.started_at:
                run.started_at = timezone.now()
            if status in ('done', 'error', 'skipped'):
                run.ended_at = timezone.now()
        if records is not None:
            run.records = records
        if errors is not None:
            run.errors = errors
        run.save(update_fields=[f for f in
            ['task_id', 'status', 'started_at', 'ended_at', 'records', 'errors']
            if getattr(run, f, None) is not None or f in ['records', 'errors']])
        push_status(run_id, run.status, run.records, run.errors)
    except Exception as exc:
        logger.error(f'update_run({run_id}) failed: {exc}')


# ──────────────────────────────────────────────────────────────
# REAL-TIME LOG CAPTURE
# ──────────────────────────────────────────────────────────────

def _classify(line: str) -> str:
    """Map a print() output line to a log level for the terminal."""
    if any(x in line for x in ['❌', 'Error:', 'ERROR', 'Exception', 'FAILED', 'failed']):
        return 'ERR'
    if any(x in line for x in ['⚠', '⚠️', 'Warning', 'WARN', 'retry', 'Retry', 'slow']):
        return 'WARN'
    if any(x in line for x in ['✅', '✦', 'COMPLETE', 'complete', 'finished',
                                 'MISSION', 'BREACHED', 'CLEARED', 'secured']):
        return 'OK'
    if any(x in line for x in ['GET ', 'POST ', 'Sending', 'Initiating', 'BEGIN',
                                 'Streaming', 'Upserting', 'Loaded', '◈', '▶', '◆']):
        return 'CMD'
    if any(x in line for x in ['📥', '📅', '📊', '📄', '💾', '📦', '📈',
                                 'records', 'Rows', 'parsed', 'Saved', 'Backup',
                                 'pushed', 'Zoho']):
        return 'DATA'
    return 'INFO'


class LogCapture(io.StringIO):
    """
    Replaces sys.stdout while a script runs.
    Every newline triggers a push_log() call — the browser sees each
    print() line appear in the terminal as soon as it is printed.
    """
    def __init__(self, run_id: int):
        super().__init__()
        self.run_id   = run_id
        self._pending = ''

    def write(self, text: str) -> int:
        super().write(text)
        self._pending += text
        while '\n' in self._pending:
            line, self._pending = self._pending.split('\n', 1)
            line = line.strip()
            # Strip ANSI escape codes (colorama adds them)
            line = re.sub(r'\x1b\[[0-9;]*m', '', line)
            if line:
                push_log(self.run_id, _classify(line), line)
        return len(text)

    def flush(self):
        super().flush()
        remainder = self._pending.strip()
        remainder = re.sub(r'\x1b\[[0-9;]*m', '', remainder)
        if remainder:
            push_log(self.run_id, _classify(remainder), remainder)
            self._pending = ''


# ──────────────────────────────────────────────────────────────
# SCRIPT PATH PATCHER
# ──────────────────────────────────────────────────────────────

def _patch_script_paths(source: str) -> str:
    """
    Replace hardcoded C:\\Users\\Akhil\\... paths with the paths from
    Django settings so scripts work from anywhere.
    """
    input_path  = str(settings.DATA_INPUT_PATH).replace('\\', '\\\\')
    repo_path   = str(settings.DATA_REPO_PATH).replace('\\', '\\\\')

    # Replace OUTPUT_PATH
    source = re.sub(
        r"OUTPUT_PATH\s*=\s*r?['\"].*?['\"]",
        f"OUTPUT_PATH = r'{settings.DATA_INPUT_PATH}'",
        source
    )
    # Replace FOLDER_PATH (Compiler.py)
    source = re.sub(
        r"FOLDER_PATH\s*=\s*r?['\"].*?['\"]",
        f"FOLDER_PATH = r'{settings.DATA_REPO_PATH}'",
        source
    )
    # Replace INPUT_PATH (Compiler.py)
    source = re.sub(
        r"INPUT_PATH\s*=\s*r?['\"].*?['\"]",
        f"INPUT_PATH = r'{settings.DATA_INPUT_PATH}'",
        source
    )
    return source


# ──────────────────────────────────────────────────────────────
# SCRIPT EXECUTOR
# ──────────────────────────────────────────────────────────────

def execute_script(script_path: str, run_id: int) -> tuple:
    """
    Load a .py file, patch its hardcoded paths, then exec it.
    Captures all print() output line-by-line and streams to terminal.
    Returns (collected_count, error_count).
    """
    push_log(run_id, 'CMD', f'$ python {os.path.basename(script_path)}')

    if not os.path.exists(script_path):
        push_log(run_id, 'ERR', f'Script not found: {script_path}')
        push_log(run_id, 'ERR', f'Copy your .py files into the scripts/ folder')
        raise FileNotFoundError(script_path)

    # Read source and patch paths
    with open(script_path, 'r', encoding='utf-8', errors='replace') as f:
        source = f.read()
    source = _patch_script_paths(source)

    # Redirect stdout + stderr
    old_out, old_err = sys.stdout, sys.stderr
    capture = LogCapture(run_id)
    sys.stdout = capture
    sys.stderr = capture

    collected   = 0
    error_count = 0

    try:
        # Compile and exec the patched source
        code = compile(source, script_path, 'exec')
        module_globals = {
            '__name__':            '__main__',
            '__file__':            script_path,
            '__vikrant_run_id__':  run_id,
        }
        exec(code, module_globals)

        # Grab stats that scripts set as globals
        collected = int(
            module_globals.get('collected_count', 0) or
            module_globals.get('pushed_sent', 0) or 0
        )

    except SystemExit as e:
        if e.code not in (0, None):
            error_count = 1
            push_log(run_id, 'WARN', f'Script exited with code {e.code}')

    except Exception:
        error_count = 1
        tb = traceback.format_exc()
        for line in tb.splitlines():
            clean = re.sub(r'\x1b\[[0-9;]*m', '', line)
            if clean.strip():
                push_log(run_id, 'ERR', clean)
        raise

    finally:
        sys.stdout = old_out
        sys.stderr = old_err
        capture.flush()

    return collected, error_count


# ──────────────────────────────────────────────────────────────
# CELERY TASKS
# ──────────────────────────────────────────────────────────────

@shared_task(bind=True, max_retries=2, default_retry_delay=30,
             name='scraper.tasks.run_scraper_task',
             soft_time_limit=7200)
def run_scraper_task(self, run_id: int, script_filename: str):
    """
    One Celery task = one scraper script.
    7 of these run IN PARALLEL across Celery worker slots.

    bind=True       → self.request.id = Celery task UUID (for revoke/stop)
    max_retries=2   → auto-retry on crash with 30s gap
    soft_time_limit → kills after 2h if stuck
    """
    update_run(run_id, status='running', task_id=self.request.id)
    push_log(run_id, 'SYS', f'▶ Worker started: {script_filename}')
    push_log(run_id, 'SYS', f'  Celery task: {self.request.id}')

    script_path = str(settings.SCRIPTS_DIR / script_filename)
    t0 = time.time()

    try:
        collected, errors = execute_script(script_path, run_id)
        elapsed = round(time.time() - t0, 1)

        update_run(run_id, status='done', records=collected, errors=errors)
        push_log(run_id, 'OK',
                 f'✦ {script_filename} done in {elapsed}s — {collected} records')
        return {'run_id': run_id, 'records': collected, 'errors': errors}

    except FileNotFoundError:
        update_run(run_id, status='error', errors=1)
        return {'run_id': run_id, 'records': 0, 'errors': 1}

    except Exception as exc:
        update_run(run_id, status='error', errors=1)
        push_log(run_id, 'ERR', f'Task failed: {exc}')
        try:
            raise self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            push_log(run_id, 'ERR', 'Max retries reached — aborting')
            return {'run_id': run_id, 'records': 0, 'errors': 1}


@shared_task(bind=True, max_retries=1, default_retry_delay=15,
             name='scraper.tasks.run_compiler_task',
             soft_time_limit=3600)
def run_compiler_task(self, scraper_results, run_id: int, script_filename: str):
    """
    Runs AFTER all scrapers finish (Celery chord callback).
    scraper_results = list of dicts returned by each run_scraper_task.
    """
    update_run(run_id, status='running', task_id=self.request.id)

    total_scraped = sum(
        r.get('records', 0) for r in (scraper_results or [])
        if isinstance(r, dict)
    )
    push_log(run_id, 'SYS', '▶ All scrapers complete — starting Compiler')
    push_log(run_id, 'INFO', f'  Total records from scrapers: {total_scraped}')

    script_path = str(settings.SCRIPTS_DIR / script_filename)
    t0 = time.time()

    try:
        collected, errors = execute_script(script_path, run_id)
        elapsed = round(time.time() - t0, 1)

        update_run(run_id, status='done', records=collected, errors=errors)
        push_log(run_id, 'OK',
                 f'✦ Compiler done in {elapsed}s — {collected} records pushed to Zoho')
        return {'run_id': run_id, 'records': collected}

    except Exception as exc:
        update_run(run_id, status='error', errors=1)
        push_log(run_id, 'ERR', f'Compiler failed: {exc}')
        try:
            raise self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            return {'run_id': run_id, 'records': 0, 'errors': 1}


@shared_task(bind=True, max_retries=1, default_retry_delay=10,
             name='scraper.tasks.run_modem_task',
             soft_time_limit=600)
def run_modem_task(self, compiler_result, run_id: int, script_filename: str):
    """Runs after compiler. Reboots the modem via Selenium."""
    update_run(run_id, status='running', task_id=self.request.id)
    push_log(run_id, 'SYS', '▶ Compiler done — modem reboot starting')

    script_path = str(settings.SCRIPTS_DIR / script_filename)
    t0 = time.time()

    try:
        execute_script(script_path, run_id)
        elapsed = round(time.time() - t0, 1)

        update_run(run_id, status='done')
        push_log(run_id, 'OK', f'✦ Modem reboot complete in {elapsed}s')
        push_log(run_id, 'SYS', '═══ FULL PIPELINE COMPLETE ═══')
        return {'run_id': run_id}

    except Exception as exc:
        update_run(run_id, status='error', errors=1)
        push_log(run_id, 'ERR', f'Modem reboot failed: {exc}')
        try:
            raise self.retry(exc=exc)
        except self.MaxRetriesExceededError:
            return {'run_id': run_id, 'errors': 1}


@shared_task(name='scraper.tasks.beat_trigger_pipeline')
def beat_trigger_pipeline():
    """Called by Celery Beat every hour. Starts a full pipeline run."""
    _ws_send('pipeline_status', {
        'type': 'global.log',
        'level': 'SYS',
        'message': '⏰ Hourly scheduled run triggered by Celery Beat',
        'ts': datetime.now().strftime('%H:%M:%S'),
    })
    launch_full_pipeline(triggered_by='beat')


# ──────────────────────────────────────────────────────────────
# PIPELINE LAUNCHER (called from views.py)
# ──────────────────────────────────────────────────────────────

def launch_full_pipeline(triggered_by: str = 'manual') -> dict:
    """
    Builds and fires this Celery workflow:

        group(
            run_scraper_task(black_hat_run, 'Black_Hat...py'),
            run_scraper_task(inf_run,       'Inf_-_Insta...py'),
            run_scraper_task(inshar_run,    'Inshar...py'),
            run_scraper_task(mr_run,        'MR...py'),
            run_scraper_task(wx_bd_run,     'WX_BD...py'),
            run_scraper_task(wx_sar_run,    'WX_SAR...py'),
            run_scraper_task(xna_run,       'XNA...py'),
        )
        | run_compiler_task(compiler_run, 'Compiler.py')
        | run_modem_task(modem_run, 'modem_reboot.py')

    The | operator means: start the next task only when the previous
    group/task has completely finished.
    """
    from scraper.models import ScraperScript, ScraperRun, PipelineRun

    scrapers = list(ScraperScript.objects.filter(
        is_compiler=False, is_modem=False, is_active=True
    ).order_by('order'))
    compiler = ScraperScript.objects.filter(is_compiler=True, is_active=True).first()
    modem    = ScraperScript.objects.filter(is_modem=True,    is_active=True).first()

    if not scrapers and not compiler:
        raise ValueError(
            'No active scripts found. Go to /admin/scraper/scraperscript/ and add them.'
        )

    # Create PipelineRun parent record
    pipeline = PipelineRun.objects.create(
        status='running',
        started_at=timezone.now(),
        triggered_by=triggered_by
    )

    # Create a ScraperRun for every script
    scraper_runs = [
        ScraperRun.objects.create(pipeline=pipeline, script=s, status='pending')
        for s in scrapers
    ]
    compiler_run = ScraperRun.objects.create(
        pipeline=pipeline, script=compiler, status='pending'
    ) if compiler else None
    modem_run = ScraperRun.objects.create(
        pipeline=pipeline, script=modem, status='pending'
    ) if modem else None

    # Notify browser that pipeline started
    _ws_send('pipeline_status', {
        'type':    'pipeline.started',
        'pipeline_id': pipeline.id,
        'scraper_run_ids':  [r.id for r in scraper_runs],
        'compiler_run_id':  compiler_run.id if compiler_run else None,
        'modem_run_id':     modem_run.id    if modem_run    else None,
        'ts': datetime.now().strftime('%H:%M:%S'),
    })

    # ── Build Celery workflow ──────────────────────────────────
    if scraper_runs:
        parallel_group = group(
            run_scraper_task.s(r.id, r.script.filename)
            for r in scraper_runs
        )
    else:
        parallel_group = None

    if parallel_group and compiler_run and modem_run:
        workflow = (
            parallel_group
            | run_compiler_task.s(compiler_run.id, compiler_run.script.filename)
            | run_modem_task.s(modem_run.id, modem_run.script.filename)
        )
    elif parallel_group and compiler_run:
        workflow = (
            parallel_group
            | run_compiler_task.s(compiler_run.id, compiler_run.script.filename)
        )
    elif compiler_run:
        workflow = run_compiler_task.si(
            [], compiler_run.id, compiler_run.script.filename
        )
    else:
        workflow = parallel_group

    workflow.delay()

    return {
        'ok':              True,
        'pipeline_id':     pipeline.id,
        'scraper_run_ids': [r.id for r in scraper_runs],
        'compiler_run_id': compiler_run.id if compiler_run else None,
        'modem_run_id':    modem_run.id    if modem_run    else None,
        'all_run_ids': (
            [r.id for r in scraper_runs]
            + ([compiler_run.id] if compiler_run else [])
            + ([modem_run.id]    if modem_run    else [])
        ),
    }
