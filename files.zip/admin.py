from django.contrib import admin
from .models import ScraperScript, ScraperRun, PipelineRun, LogLine


@admin.register(ScraperScript)
class ScraperScriptAdmin(admin.ModelAdmin):
    list_display  = ['name', 'filename', 'stage_label', 'is_active', 'order']
    list_editable = ['is_active', 'order']
    list_filter   = ['is_compiler', 'is_modem', 'is_active']
    fieldsets = (
        (None, {'fields': ('name', 'filename', 'description', 'is_active', 'order')}),
        ('Script type (check only one)', {
            'fields': ('is_compiler', 'is_modem'),
            'description': (
                'is_compiler → Compiler.py  |  '
                'is_modem → modem_reboot.py  |  '
                'neither → regular scraper'
            ),
        }),
    )


@admin.register(PipelineRun)
class PipelineRunAdmin(admin.ModelAdmin):
    list_display    = ['id', 'status', 'triggered_by', 'started_at', 'ended_at']
    list_filter     = ['status', 'triggered_by']
    readonly_fields = ['started_at', 'ended_at', 'created_at']


@admin.register(ScraperRun)
class ScraperRunAdmin(admin.ModelAdmin):
    list_display    = ['id', 'script', 'status', 'records', 'errors',
                       'elapsed_seconds', 'started_at']
    list_filter     = ['status', 'script']
    readonly_fields = ['task_id', 'started_at', 'ended_at', 'created_at']
    ordering        = ['-created_at']


@admin.register(LogLine)
class LogLineAdmin(admin.ModelAdmin):
    list_display = ['timestamp', 'run', 'level', '_preview']
    list_filter  = ['level', 'run__script']
    ordering     = ['-timestamp']

    def _preview(self, obj):
        return obj.message[:120]
    _preview.short_description = 'Message'
