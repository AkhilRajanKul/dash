"""
Management command: python manage.py seed_scripts

Registers all 9 scripts in the ScraperScript table.
Run this once after python manage.py migrate.
"""

from django.core.management.base import BaseCommand
from scraper.models import ScraperScript


SCRIPTS = [
    # (name, filename, is_compiler, is_modem, order)
    # ── Scrapers (run in parallel, order doesn't matter for execution) ──
    ('Black Hat Meta',   'Black_Hat_-_Meta_creeper.py', False, False, 1),
    ('Inf Insta',        'Inf_-_Insta_creeper.py',      False, False, 2),
    ('Inshar Meta',      'Inshar_-_Meta_creeper.py',    False, False, 3),
    ('MR Meta',          'MR_-_Meta_creeper.py',        False, False, 4),
    ('WX BD',            'WX_BD_Creeper.py',            False, False, 5),
    ('WX SAR',           'WX_SAR_creeper.py',           False, False, 6),
    ('XNA Meta',         'XNA_-_Meta_creeper.py',       False, False, 7),
    # ── Compiler (runs after ALL scrapers finish) ──
    ('Compiler',         'Compiler.py',                 True,  False, 0),
    # ── Modem reboot (runs after compiler) ──
    ('Modem Reboot',     'modem_reboot.py',             False, True,  0),
]


class Command(BaseCommand):
    help = 'Seeds the ScraperScript table with all 9 Vikrant scripts'

    def handle(self, *args, **options):
        self.stdout.write('\nSeeding ScraperScript table...\n')

        for name, filename, is_compiler, is_modem, order in SCRIPTS:
            obj, created = ScraperScript.objects.update_or_create(
                filename=filename,
                defaults={
                    'name':        name,
                    'is_compiler': is_compiler,
                    'is_modem':    is_modem,
                    'is_active':   True,
                    'order':       order,
                }
            )
            action = 'Created' if created else 'Updated'
            stage  = 'compiler' if is_compiler else ('modem' if is_modem else 'scraper')
            self.stdout.write(
                f'  {action}: [{stage:8}] {name} ({filename})'
            )

        total = ScraperScript.objects.count()
        self.stdout.write(f'\nDone. {total} scripts in database.\n')
        self.stdout.write(
            'Manage at: http://localhost:8000/admin/scraper/scraperscript/\n'
        )
