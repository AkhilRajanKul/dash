from django.contrib import admin
from django.urls import path
from scraper import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.dashboard, name='dashboard'),
    # Pipeline control
    path('api/pipeline/start/',  views.start_pipeline,  name='start_pipeline'),
    path('api/pipeline/stop/',   views.stop_pipeline,   name='stop_pipeline'),
    path('api/pipeline/status/', views.all_runs_status, name='all_runs_status'),
    # Per-run data
    path('api/run/<int:run_id>/',      views.run_status, name='run_status'),
    path('api/run/<int:run_id>/logs/', views.run_logs,   name='run_logs'),
    # Scripts list
    path('api/scripts/', views.list_scripts, name='list_scripts'),
]
