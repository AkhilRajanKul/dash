from django.db import models
from django.utils import timezone


class ScraperScript(models.Model):
    """
    One row = one .py file.
    Add rows via /admin/ or the seed_scripts management command.
    """
    name        = models.CharField(max_length=120, unique=True)
    filename    = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    is_compiler = models.BooleanField(default=False)
    is_modem    = models.BooleanField(default=False)
    is_active   = models.BooleanField(default=True)
    order       = models.IntegerField(default=0)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['order', 'name']

    def stage_label(self):
        if self.is_compiler: return 'compiler'
        if self.is_modem:    return 'modem'
        return 'scraper'

    def __str__(self):
        return self.name


class PipelineRun(models.Model):
    """One full pipeline execution (all scrapers + compiler + modem)."""
    STATUS_CHOICES = [
        ('pending', 'Pending'), ('running', 'Running'),
        ('done',    'Done'),    ('error',   'Error'),
        ('stopped', 'Stopped'),
    ]
    status       = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    triggered_by = models.CharField(max_length=50, default='manual')
    started_at   = models.DateTimeField(null=True, blank=True)
    ended_at     = models.DateTimeField(null=True, blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def elapsed(self):
        if self.started_at:
            end = self.ended_at or timezone.now()
            return int((end - self.started_at).total_seconds())
        return 0

    def __str__(self):
        return f'Pipeline #{self.id} [{self.status}]'


class ScraperRun(models.Model):
    """One script execution within a pipeline."""
    STATUS_CHOICES = [
        ('pending',  'Pending'),  ('running', 'Running'),
        ('done',     'Done'),     ('error',   'Error'),
        ('skipped',  'Skipped'),
    ]
    pipeline   = models.ForeignKey(PipelineRun, on_delete=models.CASCADE,
                                   related_name='scraper_runs', null=True, blank=True)
    script     = models.ForeignKey(ScraperScript, on_delete=models.CASCADE,
                                   related_name='runs')
    status     = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    task_id    = models.CharField(max_length=155, blank=True, db_index=True)
    records    = models.IntegerField(default=0)
    errors     = models.IntegerField(default=0)
    started_at = models.DateTimeField(null=True, blank=True)
    ended_at   = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes  = [models.Index(fields=['status', 'created_at'])]

    def elapsed_seconds(self):
        if self.started_at:
            end = self.ended_at or timezone.now()
            return int((end - self.started_at).total_seconds())
        return 0

    def to_dict(self):
        return {
            'id':          self.id,
            'script_id':   self.script_id,
            'script_name': self.script.name,
            'filename':    self.script.filename,
            'stage':       self.script.stage_label(),
            'status':      self.status,
            'task_id':     self.task_id,
            'records':     self.records,
            'errors':      self.errors,
            'elapsed':     self.elapsed_seconds(),
        }

    def __str__(self):
        return f'{self.script.name} [{self.status}]'


class LogLine(models.Model):
    """One terminal log message from a running script."""
    LEVEL_CHOICES = [
        ('INFO', 'Info'), ('OK',   'OK'),   ('WARN', 'Warning'),
        ('ERR',  'Error'), ('CMD', 'Cmd'),  ('SYS',  'System'),
        ('DATA', 'Data'),
    ]
    run       = models.ForeignKey(ScraperRun, on_delete=models.CASCADE,
                                  related_name='logs')
    level     = models.CharField(max_length=10, choices=LEVEL_CHOICES, default='INFO')
    message   = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['timestamp']
        indexes  = [
            models.Index(fields=['run', 'timestamp']),
            models.Index(fields=['level']),
        ]

    def to_dict(self):
        return {
            'level':   self.level,
            'message': self.message,
            'ts':      self.timestamp.strftime('%H:%M:%S'),
        }

    def __str__(self):
        return f'[{self.level}] {self.message[:80]}'
