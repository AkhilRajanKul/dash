"""
Vikrant Dashboard — Django Settings
Supports PostgreSQL (production) with SQLite fallback
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'vikrant-secret-key-change-before-deploying-2024-xkq92'

DEBUG = True
ALLOWED_HOSTS = ['*']

# ── Toggle: set False to use SQLite instead of PostgreSQL ──
USE_POSTGRES = True

# ─────────────────────────────────────────────────────────────
# YOUR DATA PATHS — UPDATE THESE TO MATCH YOUR MACHINE
# ─────────────────────────────────────────────────────────────
DATA_INPUT_PATH = r"C:\Users\Akhil\Desktop\Vikrant\data\input"
DATA_REPO_PATH  = r"C:\Users\Akhil\Desktop\Vikrant\data\repo"

# Scripts directory (inside the Django project)
SCRIPTS_DIR = BASE_DIR / 'scripts'

# ─────────────────────────────────────────────────────────────
# INSTALLED APPS
# ─────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # Third party
    'channels',
    'rest_framework',
    'django_celery_beat',
    'django_celery_results',
    # Our app
    'scraper',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'vikrant.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

ASGI_APPLICATION = 'vikrant.asgi.application'
WSGI_APPLICATION = 'vikrant.wsgi.application'

# ─────────────────────────────────────────────────────────────
# DATABASE — PostgreSQL (recommended) or SQLite (fallback)
# ─────────────────────────────────────────────────────────────
if USE_POSTGRES:
    DATABASES = {
        'default': {
            'ENGINE':   'django.db.backends.postgresql',
            'NAME':     'vikrant_db',
            'USER':     'vikrant_user',
            'PASSWORD': 'vikrant2024secure',
            'HOST':     '127.0.0.1',
            'PORT':     '5432',
            # Connection pool — keeps DB connections alive between requests
            'CONN_MAX_AGE': 60,
            'OPTIONS': {
                'connect_timeout': 10,
            },
        }
    }
else:
    # SQLite fallback — no installation needed, but not for production
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME':   BASE_DIR / 'db.sqlite3',
        }
    }

# ─────────────────────────────────────────────────────────────
# REDIS
# ─────────────────────────────────────────────────────────────
REDIS_URL = os.environ.get('REDIS_URL', 'redis://127.0.0.1:6379/0')

# Django Channels — WebSocket pub/sub layer
CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            'hosts': [REDIS_URL],
            'capacity': 1500,
            'expiry': 60,
        },
    }
}

# ─────────────────────────────────────────────────────────────
# CELERY
# ─────────────────────────────────────────────────────────────
CELERY_BROKER_URL              = REDIS_URL
CELERY_RESULT_BACKEND          = 'django-db'    # stores results in PostgreSQL
CELERY_CACHE_BACKEND           = 'django-cache'
CELERY_TASK_SERIALIZER         = 'json'
CELERY_RESULT_SERIALIZER       = 'json'
CELERY_ACCEPT_CONTENT          = ['json']
CELERY_TIMEZONE                = 'Asia/Kolkata'
CELERY_TASK_TRACK_STARTED      = True
CELERY_TASK_ACKS_LATE          = True
CELERY_WORKER_PREFETCH_MULTIPLIER = 1
CELERY_TASK_SOFT_TIME_LIMIT    = 7200   # 2 hours max per task
CELERY_TASK_TIME_LIMIT         = 7500

# Celery Beat — schedule hourly pipeline
from celery.schedules import crontab
CELERY_BEAT_SCHEDULER = 'django_celery_beat.schedulers:DatabaseScheduler'
CELERY_BEAT_SCHEDULE = {
    'hourly-full-pipeline': {
        'task':     'scraper.tasks.beat_trigger_pipeline',
        'schedule': crontab(minute=0),   # every hour on the hour
    },
}

# ─────────────────────────────────────────────────────────────
# STATIC FILES
# ─────────────────────────────────────────────────────────────
STATIC_URL       = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT      = BASE_DIR / 'staticfiles'

# ─────────────────────────────────────────────────────────────
# MISC
# ─────────────────────────────────────────────────────────────
LANGUAGE_CODE      = 'en-us'
TIME_ZONE          = 'Asia/Kolkata'
USE_I18N           = True
USE_TZ             = True
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Cache (used by Celery results backend)
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': REDIS_URL,
    }
}

# ─────────────────────────────────────────────────────────────
# LOGGING — shows what scrapers print to the Celery window
# ─────────────────────────────────────────────────────────────
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'colored': {
            'format': '[{asctime}] [{levelname}] {name}: {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class':     'logging.StreamHandler',
            'formatter': 'colored',
        },
    },
    'root': {'handlers': ['console'], 'level': 'INFO'},
    'loggers': {
        'scraper':  {'handlers': ['console'], 'level': 'DEBUG', 'propagate': False},
        'celery':   {'handlers': ['console'], 'level': 'INFO',  'propagate': False},
        'channels': {'handlers': ['console'], 'level': 'WARNING', 'propagate': False},
        'daphne':   {'handlers': ['console'], 'level': 'WARNING', 'propagate': False},
    },
}

# ─────────────────────────────────────────────────────────────
# SECURITY (relax for local dev — tighten before going public)
# ─────────────────────────────────────────────────────────────
CSRF_TRUSTED_ORIGINS = [
    'http://localhost:8000',
    'http://127.0.0.1:8000',
]
